# BestieConnet

A phone-number-based messaging and social connection app starter built with Expo and React Native.

## Current starter features
- BestieConnet branded home screen
- Chats, Updates, Calls and Settings tabs
- Sample conversation list and local search
- Initial UI foundation for the contact-first messaging experience

## Contact-first messaging rule
A user can start a private chat with a registered BestieConnet user when the sender has that recipient's phone number saved in their device contacts. The recipient does not have to save the sender's number.

## Run the app
1. Install dependencies: `npm install`
2. Start Expo: `npx expo start`
3. Scan the QR code using Expo Go, or use an Android emulator.

## Important
This is the initial UI starter, not a finished messaging service. Phone-number OTP authentication, secure contact matching, real-time chat, media uploads, calls, push notifications, and end-to-end encryption still need to be implemented and tested before public release. Contact matching should be designed with privacy-preserving server-side methods and clear user consent.
