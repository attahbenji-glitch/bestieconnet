import React, { useState } from "react";
import {
  SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList,
  Image, StyleSheet, StatusBar, ScrollView
} from "react-native";

type Tab = "Chats" | "Updates" | "Calls" | "Settings";

const initialChats = [
  { id: "1", name: "BestieConnet Team", message: "Welcome! Your community starts here.", time: "9:41 AM", unread: 1, initials: "B" },
  { id: "2", name: "Ada", message: "Hey, how are you doing?", time: "Yesterday", unread: 0, initials: "A" },
  { id: "3", name: "Family Group", message: "Mum: Have a lovely day ❤️", time: "Yesterday", unread: 0, initials: "F" },
];

export default function App() {
  const [tab, setTab] = useState<Tab>("Chats");
  const [query, setQuery] = useState("");

  const filteredChats = initialChats.filter(c =>
    c.name.toLowerCase().includes(query.toLowerCase())
  );

  const renderChat = ({ item }: { item: typeof initialChats[number] }) => (
    <TouchableOpacity style={styles.chatRow} activeOpacity={0.7}>
      <View style={styles.avatar}><Text style={styles.avatarText}>{item.initials}</Text></View>
      <View style={styles.chatInfo}>
        <View style={styles.chatTop}>
          <Text style={styles.chatName}>{item.name}</Text>
          <Text style={styles.time}>{item.time}</Text>
        </View>
        <View style={styles.chatBottom}>
          <Text style={styles.preview} numberOfLines={1}>{item.message}</Text>
          {item.unread > 0 && <View style={styles.unread}><Text style={styles.unreadText}>{item.unread}</Text></View>}
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>BestieConnet</Text>
          <Text style={styles.tagline}>Your people. Your conversations.</Text>
        </View>
        <TouchableOpacity style={styles.headerButton}>
          <Text style={styles.headerButtonText}>＋</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.tabs}>
        {(["Chats", "Updates", "Calls", "Settings"] as Tab[]).map(t => (
          <TouchableOpacity key={t} onPress={() => setTab(t)} style={[styles.tab, tab === t && styles.activeTab]}>
            <Text style={[styles.tabText, tab === t && styles.activeTabText]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {tab === "Chats" ? (
        <>
          <View style={styles.searchWrap}>
            <Text style={styles.searchIcon}>⌕</Text>
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="Search your conversations"
              placeholderTextColor="#89939E"
              style={styles.search}
            />
          </View>
          <View style={styles.sectionHeading}>
            <Text style={styles.sectionTitle}>MESSAGES</Text>
            <Text style={styles.sectionHint}>Only your contacts can start a chat</Text>
          </View>
          <FlatList
            data={filteredChats}
            renderItem={renderChat}
            keyExtractor={item => item.id}
            ListEmptyComponent={<Text style={styles.empty}>No conversations found.</Text>}
            contentContainerStyle={{ paddingBottom: 24 }}
          />
          <TouchableOpacity style={styles.fab} activeOpacity={0.8}>
            <Text style={styles.fabText}>✎</Text>
          </TouchableOpacity>
        </>
      ) : tab === "Updates" ? (
        <ScrollView contentContainerStyle={styles.placeholderPage}>
          <View style={styles.storyCircle}><Text style={styles.storyPlus}>＋</Text></View>
          <Text style={styles.pageTitle}>Share an update</Text>
          <Text style={styles.pageText}>Post a photo, video or text update for the people you choose.</Text>
          <TouchableOpacity style={styles.primaryButton}><Text style={styles.primaryButtonText}>Create update</Text></TouchableOpacity>
        </ScrollView>
      ) : tab === "Calls" ? (
        <View style={styles.placeholderPage}>
          <Text style={styles.largeIcon}>☎</Text>
          <Text style={styles.pageTitle}>Your calls</Text>
          <Text style={styles.pageText}>Voice and video calling will be added in a later development stage.</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.settingsPage}>
          <View style={styles.profileAvatar}><Text style={styles.profileAvatarText}>B</Text></View>
          <Text style={styles.pageTitle}>Your profile</Text>
          <Text style={styles.pageText}>Set up your name, photo and BestieConnet account.</Text>
          {["Account", "Privacy", "Notifications", "Chats", "Help"].map(x => (
            <TouchableOpacity key={x} style={styles.settingRow}>
              <Text style={styles.settingLabel}>{x}</Text><Text style={styles.chevron}>›</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}
      <View style={styles.footer}><Text style={styles.footerText}>BESTIECONNET  •  CONNECT WITH YOUR PEOPLE</Text></View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#FFFFFF" },
  header: { paddingHorizontal: 20, paddingTop: 14, paddingBottom: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  brand: { fontSize: 25, fontWeight: "800", color: "#172B4D", letterSpacing: -0.6 },
  tagline: { marginTop: 3, fontSize: 12, color: "#7A8796" },
  headerButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#EAF7F3", alignItems: "center", justifyContent: "center" },
  headerButtonText: { fontSize: 28, lineHeight: 31, color: "#119B78" },
  tabs: { flexDirection: "row", borderBottomWidth: 1, borderBottomColor: "#EDF0F2", paddingHorizontal: 12 },
  tab: { flex: 1, alignItems: "center", paddingVertical: 13, borderBottomWidth: 3, borderBottomColor: "transparent" },
  activeTab: { borderBottomColor: "#119B78" },
  tabText: { color: "#84909C", fontSize: 13, fontWeight: "600" },
  activeTabText: { color: "#119B78" },
  searchWrap: { marginHorizontal: 18, marginTop: 18, marginBottom: 20, backgroundColor: "#F3F6F7", borderRadius: 13, height: 46, flexDirection: "row", alignItems: "center", paddingHorizontal: 13 },
  searchIcon: { fontSize: 24, color: "#7B8995", marginRight: 8 },
  search: { flex: 1, color: "#172B4D", fontSize: 14, paddingVertical: 0 },
  sectionHeading: { paddingHorizontal: 20, paddingBottom: 8, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  sectionTitle: { color: "#119B78", fontSize: 10, fontWeight: "800", letterSpacing: 1.2 },
  sectionHint: { color: "#9AA4AE", fontSize: 10 },
  chatRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 18, paddingVertical: 13 },
  avatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: "#E4F4EF", alignItems: "center", justifyContent: "center", marginRight: 13 },
  avatarText: { color: "#119B78", fontSize: 19, fontWeight: "800" },
  chatInfo: { flex: 1, borderBottomWidth: 1, borderBottomColor: "#F1F3F4", paddingBottom: 12 },
  chatTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 6 },
  chatName: { fontSize: 15, fontWeight: "700", color: "#1D2D3D" },
  time: { fontSize: 10, color: "#9AA4AE" },
  chatBottom: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  preview: { color: "#7D8994", fontSize: 12, flex: 1, marginRight: 8 },
  unread: { backgroundColor: "#119B78", minWidth: 19, height: 19, borderRadius: 10, alignItems: "center", justifyContent: "center", paddingHorizontal: 5 },
  unreadText: { color: "#FFFFFF", fontSize: 10, fontWeight: "700" },
  empty: { textAlign: "center", marginTop: 35, color: "#87939E" },
  fab: { position: "absolute", right: 20, bottom: 25, width: 55, height: 55, borderRadius: 18, backgroundColor: "#119B78", alignItems: "center", justifyContent: "center", elevation: 5 },
  fabText: { color: "#FFFFFF", fontSize: 25 },
  placeholderPage: { flexGrow: 1, alignItems: "center", justifyContent: "center", padding: 32 },
  storyCircle: { width: 74, height: 74, borderRadius: 37, borderWidth: 2, borderColor: "#119B78", alignItems: "center", justifyContent: "center", marginBottom: 18 },
  storyPlus: { color: "#119B78", fontSize: 34 },
  largeIcon: { fontSize: 54, color: "#119B78", marginBottom: 14 },
  pageTitle: { fontSize: 20, fontWeight: "800", color: "#172B4D", marginBottom: 8, textAlign: "center" },
  pageText: { color: "#84909C", fontSize: 13, lineHeight: 20, textAlign: "center", maxWidth: 280 },
  primaryButton: { backgroundColor: "#119B78", paddingHorizontal: 24, paddingVertical: 13, borderRadius: 12, marginTop: 22 },
  primaryButtonText: { color: "#FFFFFF", fontWeight: "700" },
  settingsPage: { alignItems: "center", padding: 22 },
  profileAvatar: { width: 82, height: 82, borderRadius: 41, backgroundColor: "#E4F4EF", alignItems: "center", justifyContent: "center", marginTop: 12, marginBottom: 14 },
  profileAvatarText: { fontSize: 30, fontWeight: "800", color: "#119B78" },
  settingRow: { width: "100%", paddingVertical: 18, borderBottomWidth: 1, borderBottomColor: "#EFF2F3", flexDirection: "row", justifyContent: "space-between" },
  settingLabel: { color: "#243746", fontSize: 14, fontWeight: "600" },
  chevron: { color: "#9AA4AE", fontSize: 22, lineHeight: 22 },
  footer: { borderTopWidth: 1, borderTopColor: "#F2F4F5", paddingVertical: 10, alignItems: "center" },
  footerText: { color: "#A3ADB6", fontSize: 8, letterSpacing: 1.1, fontWeight: "700" },
});
